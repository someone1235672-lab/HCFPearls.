package org.zombiemace.pearlsHCF;

import org.bukkit.plugin.java.JavaPlugin;

public final class PearlsHCF extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
